package funsets

object Main extends App {
  import FunSets._
  val set1 = singletonSet(1)
  val set2 = singletonSet(1)
  println("test union : " + contains(union(set1, set2), 10))
  println("test intersect : " + contains(intersect(set1, set2), 1))
}
